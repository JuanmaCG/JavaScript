let cadena = "Hola Mundo";
console.log(cadena.length);
console.log(cadena.toUpperCase());
console.log(cadena.toLowerCase());
console.log(cadena.indexOf("o"));
console.log(cadena.substring("Hola"));
console.log(cadena.replace("Hola" , "Youtube"));
console.log(cadena.substring(5));
console.log(cadena.startsWith("h"));
console.log(cadena.startsWith("H"));
console.log("r".repeat(10));


let nombre = "Juanma";
let apellidos = "Conde Garcia";
let edad = 23;
let yop = (`Me llamo ${nombre} ${apellidos} y tengo ${edad} años`);
console.log(yop);