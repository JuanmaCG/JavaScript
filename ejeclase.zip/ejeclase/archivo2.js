let num1 = 5;
let num2 = 2;

console.log(num1 + num2);
console.log(num1 - num2);
console.log(num1 * num2);
console.log(num1 / num2);
console.log(5 % 2);

let nombre = "Juanma";

document.write('<h1>' + "hola " + nombre);

