let a = 5;
console.log(a);
console.log(a++);
console.log(a);
console.log(++a);

let b = 5;
console.log(b);
console.log(b--);
console.log(b);
console.log(--b);