let numero = -4;
let palabra = "Hola Mundo";
let respuesta = true;
const PI = Math.PI;

console.log(numero, palabra, respuesta, PI);