console.log(Math.random() * 100);

console.log(Math.PI);
console.log(Math.random() * (5) + 5); 
console.log(Math.sign(-5));
console.log(Math.sign(0));
console.log(Math.sign(5));